import crypto from 'crypto';

const generateSecret = () => {
  return crypto.randomBytes(64).toString('hex');
};

export const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key-for-testing-only';
